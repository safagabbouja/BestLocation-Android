<?php
require_once 'config.php';

// array for JSON response
$response = array();

// Check if required parameters are present
if (isset($_POST['idposition'])) { // Ensure this brace opens and matches properly

    // Get the ID of the position to delete
    $idposition = $_POST['idposition'];

    // Connect to the database
    $con = mysqli_connect($server, $user, $mp, $database, $port);

    // Check if the connection is successful
    if (!$con) {
        $response["success"] = 0;
        $response["message"] = "Database connection failed: " . mysqli_connect_error();
        echo json_encode($response);
        exit();
    }

    // Delete query
    $query = "DELETE FROM Position WHERE idposition = '$idposition'";

    // Execute the query
    if (mysqli_query($con, $query)) {
        // Successfully deleted
        $response["success"] = 1;
        $response["message"] = "Position successfully deleted.";
    } else {
        // Error occurred
        $response["success"] = 0;
        $response["message"] = "Error deleting position: " . mysqli_error($con);
    }

    // Close database connection
    mysqli_close($con);

} else { // Ensure this 'else' block is properly closed
    // Required field is missing
    $response["success"] = 0;
    $response["message"] = "Required field(s) is missing";
}

// Echo JSON response
echo json_encode($response);
?>
