<?php
require_once 'config.php';

// array for JSON response
$response = array();

// Check if all required parameters are present
if (isset($_POST['longitude']) && isset($_POST['latitude']) && isset($_POST['numero']) && isset($_POST['pseudo'])) {
    
    // Get the parameters from POST request
    $longitude = $_POST['longitude'];
    $latitude = $_POST['latitude'];
    $numero = $_POST['numero'];
    $pseudo = $_POST['pseudo'];

    // Connect to the database
    $con = mysqli_connect($server, $user, $mp, $database, $port);

    // Insert query
    $query = "INSERT INTO Position (longitude, latitude, numero, pseudo) VALUES ('$longitude', '$latitude', '$numero', '$pseudo')";

    // Execute the query
    if (mysqli_query($con, $query)) {
        // Successfully inserted
        $response["success"] = 1;
        $response["message"] = "Position successfully added.";
    } else {
        // Error occurred
        $response["success"] = 0;
        $response["message"] = "Error adding position: " . mysqli_error($con);
    }

    // Close database connection
    mysqli_close($con);

} else {
    // Required field is missing
    $response["success"] = 0;
    $response["message"] = "Required field(s) is missing";
}

// Echo JSON response
echo json_encode($response);
?>
