<?php
			$user="root";
			$mp="";
			$database="locationdatabase";
			$server="127.0.0.1";
			$port="3306";
		?>
